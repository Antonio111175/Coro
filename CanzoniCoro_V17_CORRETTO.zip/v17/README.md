# Canzoni Coro V17

App Android offline per catalogare le immagini delle canzoni del coro.

- Elenco alfabetico
- Aggiunta/rinomina/eliminazione
- Importazione Galleria
- Condivisione immagini verso l'app
- Pinch-to-zoom
- Informazioni su origine, data/ora, dimensioni e file
