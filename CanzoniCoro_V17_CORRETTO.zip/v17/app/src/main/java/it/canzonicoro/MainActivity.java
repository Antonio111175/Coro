package it.canzonicoro;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.graphics.BitmapFactory;
import androidx.exifinterface.media.ExifInterface;
import android.util.Base64;
import android.view.View;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.FileDescriptor;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 101;
    private WebView web;
    private String pendingSource = "Galleria";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xfff2f4f7);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        if (getIntent() != null) handleShare(getIntent());
    }

    public class AndroidBridge {
        @JavascriptInterface public void chooseGallery() {
            pendingSource = "Galleria";
            openPicker();
        }
        @JavascriptInterface public void chooseWhatsApp() {
            pendingSource = "WhatsApp";
            openPicker();
        }
    }

    private void openPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, PICK_IMAGE);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShare(intent);
    }

    private void handleShare(Intent intent) {
        if (Intent.ACTION_SEND.equals(intent.getAction()) && intent.getType() != null && intent.getType().startsWith("image/")) {
            Uri uri = null;
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                uri = intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class);
            } else {
                uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            }
            if (uri != null) sendUriToPage(uri, "WhatsApp", System.currentTimeMillis());
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            sendUriToPage(uri, pendingSource, System.currentTimeMillis());
        }
    }

    private void sendUriToPage(Uri uri, String source, long receivedAt) {
        new Thread(() -> {
            try {
                byte[] bytes;
                try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    bytes = out.toByteArray();
                }
                String mime = getContentResolver().getType(uri);
                if (mime == null || mime.isEmpty()) mime = "image/jpeg";
                String data = "data:" + mime + ";base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
                int width = 0, height = 0;
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
                width = opts.outWidth; height = opts.outHeight;
                String exifDate = readExifDate(uri);
                String js = "window.setNativeImage(" + quote(data) + "," + quote(source) + "," + receivedAt + "," + bytes.length + "," + width + "," + height + "," + quote(exifDate == null ? "" : exifDate) + ")";
                final String script = js;
                runOnUiThread(() -> web.evaluateJavascript(script, null));
            } catch (Exception ignored) {}
        }).start();
    }

    private String readExifDate(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            ExifInterface exif = new ExifInterface(in);
            String d = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL);
            if (d == null) d = exif.getAttribute(ExifInterface.TAG_DATETIME);
            if (d == null) return null;
            try {
                Date date = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).parse(d);
                return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(date);
            } catch (Exception e) { return d; }
        } catch (Exception e) { return null; }
    }

    private String quote(String x) {
        return "'" + x.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "").replace("\r", "") + "'";
    }
}
