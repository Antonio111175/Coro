# Coro V17

App Android offline per catalogare immagini delle canzoni del coro.

- Nome app: Coro
- Versione: 1.0.17
- Elenco alfabetico
- Galleria e condivisione immagini
- Zoom con le dita
- Informazioni immagine
- Salvataggio offline
- Icona personalizzata

Per creare l'APK da GitHub: Actions → Build Coro V17 APK → Run workflow.
