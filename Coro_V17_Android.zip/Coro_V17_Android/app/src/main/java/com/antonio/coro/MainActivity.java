package com.antonio.coro;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.graphics.drawable.GradientDrawable;
import android.app.AlertDialog;
import android.widget.*;

import androidx.exifinterface.media.ExifInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_GALLERY = 101;
    private static final int PICK_WHATSAPP = 102;
    private final ArrayList<Song> songs = new ArrayList<>();
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("dd/MM/yyyy", Locale.ITALY);
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm", Locale.ITALY);
    private int currentId = -1;
    private EditText nameEdit;
    private ZoomImageView photoView;
    private TextView detailTitle;
    private TextView infoText;
    private LinearLayout listContainer;

    private int green = Color.rgb(32,163,90), blue = Color.rgb(25,118,210), whatsapp = Color.rgb(37,211,102), red = Color.rgb(211,47,47), dark = Color.rgb(66,66,66);

    static class Song {
        int id; String name=""; String file=""; String origin=""; long timestamp; long exifTimestamp=0; int width; int height; long size;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        loadSongs();
        if (Intent.ACTION_SEND.equals(getIntent().getAction()) && getIntent().getType()!=null && getIntent().getType().startsWith("image/")) {
            Uri u = getIntent().getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) { createFromUri(u, "WhatsApp"); return; }
        }
        showList();
    }

    private TextView title(String s, int sp) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(30,30,30)); t.setPadding(18,16,18,16); return t;
    }
    private Button btn(String text, int color) {
        Button b=new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setAllCaps(false); b.setBackgroundColor(color);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(12,6,12,6); b.setLayoutParams(lp); return b;
    }
    private LinearLayout root() { LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setBackgroundColor(Color.rgb(242,244,247)); return r; }

    private void showList() {
        LinearLayout r=root();
        TextView h=title("🎵  Coro",22); h.setGravity(Gravity.CENTER); r.addView(h);
        TextView sub=title("Elenco canzoni",19); sub.setGravity(Gravity.CENTER_HORIZONTAL); r.addView(sub);
        listContainer=new LinearLayout(this); listContainer.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(listContainer); r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        Button add=btn("＋  AGGIUNGI CANZONE",green); add.setOnClickListener(v->{
            Song s=new Song(); s.id=nextId(); s.name="Nuova canzone"; songs.add(s); currentId=s.id; saveSongs(); showDetail();
        }); r.addView(add);
        Button info=btn("ℹ️  INFO",blue); info.setOnClickListener(v->showAppInfo()); r.addView(info);
        setContentView(r); refreshList();
    }

    private void refreshList() {
        if(listContainer==null)return; listContainer.removeAllViews();
        ArrayList<Song> sorted=new ArrayList<>(songs); sorted.sort((a,b)->a.name.trim().compareToIgnoreCase(b.name.trim()));
        for(Song s:sorted){
            Button b=btn(s.name.length()==0?"Senza nome":s.name,Color.WHITE); b.setTextColor(Color.DKGRAY); b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL); b.setTextSize(17);
            b.setOnClickListener(v->{currentId=s.id; showDetail();}); listContainer.addView(b);
        }
    }

    private void showDetail(){
        Song s=findCurrent(); if(s==null){showList();return;}
        LinearLayout r=root();
        detailTitle=title("Canzone",21); detailTitle.setGravity(Gravity.CENTER); r.addView(detailTitle);
        nameEdit=new EditText(this); nameEdit.setSingleLine(true); nameEdit.setText(s.name); nameEdit.setTextSize(18); nameEdit.setHint("Nome canzone"); nameEdit.setPadding(16,8,16,8); r.addView(nameEdit,new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT));
        FrameLayout box=new FrameLayout(this); box.setBackgroundColor(Color.WHITE); box.setPadding(2,2,2,2); GradientDrawableBorder(box); r.addView(box,new LinearLayout.LayoutParams(-1,0,1));
        photoView=new ZoomImageView(this); box.addView(photoView,new FrameLayout.LayoutParams(-1,-1));
        if(!s.file.isEmpty()) photoView.setImageFile(new File(getFilesDir(),s.file));
        Button gal=btn("📂  SCEGLI DALLA GALLERIA",blue); gal.setOnClickListener(v->pick(PICK_GALLERY)); r.addView(gal);
        Button wa=btn("💬  IMPORTA DA WHATSAPP",whatsapp); wa.setOnClickListener(v->pick(PICK_WHATSAPP)); r.addView(wa);
        Button save=btn("💾  SALVA",green); save.setOnClickListener(v->{s.name=nameEdit.getText().toString().trim(); if(s.name.isEmpty())s.name="Senza nome"; saveSongs(); Toast.makeText(this,"Salvato",Toast.LENGTH_SHORT).show(); showList();}); r.addView(save);
        Button info=btn("ℹ️  INFO",blue); info.setOnClickListener(v->showSongInfo()); r.addView(info);
        Button del=btn("🗑️  ELIMINA",red); del.setOnClickListener(v->deleteCurrent()); r.addView(del);
        Button back=btn("←  TORNA ALL’ELENCO",dark); back.setOnClickListener(v->showList()); r.addView(back);
        setContentView(r);
    }

    private void GradientDrawableBorder(View v){
        android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(Color.WHITE); g.setStroke(2,Color.rgb(210,210,210)); g.setCornerRadius(12); v.setBackground(g);
    }

    private void pick(int code){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,code); }

    @Override protected void onActivityResult(int req,int result,Intent data){ super.onActivityResult(req,result,data); if(result!=RESULT_OK||data==null||data.getData()==null)return; createFromUri(data.getData(),req==PICK_WHATSAPP?"WhatsApp":"Galleria"); }

    private void createFromUri(Uri uri,String origin){
        try{
            Song s=findCurrent(); if(s==null){s=new Song();s.id=nextId();songs.add(s);currentId=s.id;}
            String display=getDisplayName(uri); if(s.name.equals("Nuova canzone")||s.name.isEmpty()) s.name=stripExt(display);
            File dir=new File(getFilesDir(),"images"); if(!dir.exists())dir.mkdirs();
            String ext=".jpg"; int dot=display.lastIndexOf('.'); if(dot>=0) ext=display.substring(dot).toLowerCase(Locale.ROOT); if(ext.length()>8)ext=".jpg";
            File out=new File(dir,"song_"+s.id+ext); copyUri(uri,out);
            s.file="images/"+out.getName(); s.origin=origin; s.timestamp=System.currentTimeMillis(); s.size=out.length();
            BitmapFactory.Options o=new BitmapFactory.Options(); o.inJustDecodeBounds=true; BitmapFactory.decodeFile(out.getAbsolutePath(),o); s.width=o.outWidth; s.height=o.outHeight;
            try { ExifInterface ex=new ExifInterface(out.getAbsolutePath()); long d=ex.getDateTimeOriginal(); if(d>0)s.exifTimestamp=d; }catch(Exception ignored){}
            saveSongs(); showDetail();
        }catch(Exception e){ Toast.makeText(this,"Impossibile importare l’immagine",Toast.LENGTH_LONG).show(); }
    }

    private void copyUri(Uri uri,File out)throws Exception{ try(InputStream in=getContentResolver().openInputStream(uri); OutputStream os=new FileOutputStream(out)){byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1)os.write(buf,0,n);} }
    private String getDisplayName(Uri u){String n=null;Cursor c=getContentResolver().query(u,null,null,null,null);if(c!=null){try{int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0&&c.moveToFirst())n=c.getString(i);}finally{c.close();}}return n==null?"Canzone.jpg":n;}
    private String stripExt(String n){int i=n.lastIndexOf('.');return i>0?n.substring(0,i):n;}

    private void showSongInfo(){ Song s=findCurrent();if(s==null)return; LinearLayout r=root(); TextView h=title("ℹ️  INFO",22);h.setGravity(Gravity.CENTER);r.addView(h); StringBuilder x=new StringBuilder();
        x.append("Nome: ").append(s.name).append("\n\n");
        if("WhatsApp".equals(s.origin)){x.append("Data inviata su WhatsApp: ").append(dateFmt.format(new Date(s.timestamp))).append("\n");x.append("Ora inviata su WhatsApp: ").append(timeFmt.format(new Date(s.timestamp))).append("\n\n");}
        else {long d=s.exifTimestamp>0?s.exifTimestamp:s.timestamp;x.append("Data scatto: ").append(dateFmt.format(new Date(d))).append("\n");x.append("Ora scatto: ").append(timeFmt.format(new Date(d))).append("\n\n");}
        x.append("Origine: ").append(s.origin.isEmpty()?"Non specificata":s.origin).append("\n");x.append("Dimensioni: ").append(s.width).append(" × ").append(s.height).append(" px\n");x.append("Dimensione file: ").append(formatSize(s.size));
        TextView t=title(x.toString(),17);r.addView(t,new LinearLayout.LayoutParams(-1,0,1));Button back=btn("←  INDIETRO",dark);back.setOnClickListener(v->showDetail());r.addView(back);setContentView(r); }

    private void showAppInfo(){ LinearLayout r=root();TextView h=title("ℹ️  INFO",22);h.setGravity(Gravity.CENTER);r.addView(h);TextView t=title("Coro\nVersione 1.0.17\n\nCatalogo offline delle canzoni del coro.\nLe immagini restano salvate sul dispositivo.",17);r.addView(t,new LinearLayout.LayoutParams(-1,0,1));Button b=btn("←  INDIETRO",dark);b.setOnClickListener(v->showList());r.addView(b);setContentView(r); }

    private void deleteCurrent(){Song s=findCurrent();if(s==null)return;new AlertDialog.Builder(this).setTitle("Eliminare la canzone?").setMessage(s.name).setNegativeButton("ANNULLA",null).setPositiveButton("ELIMINA",(d,w)->{if(!s.file.isEmpty())new File(getFilesDir(),s.file).delete();songs.remove(s);currentId=-1;saveSongs();showList();}).show();}

    private Song findCurrent(){for(Song s:songs)if(s.id==currentId)return s;return null;}
    private int nextId(){int m=0;for(Song s:songs)m=Math.max(m,s.id);return m+1;}
    private String formatSize(long n){if(n<1024)return n+" B";if(n<1024*1024)return String.format(Locale.ITALY,"%.1f KB",n/1024.0);return String.format(Locale.ITALY,"%.1f MB",n/1048576.0);}

    private void loadSongs(){songs.clear();String raw=getPreferences(MODE_PRIVATE).getString("songs","[]");try{JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Song s=new Song();s.id=o.optInt("id");s.name=o.optString("name");s.file=o.optString("file");s.origin=o.optString("origin");s.timestamp=o.optLong("timestamp");s.exifTimestamp=o.optLong("exif");s.width=o.optInt("width");s.height=o.optInt("height");s.size=o.optLong("size");songs.add(s);}}catch(Exception ignored){}}
    private void saveSongs(){try{JSONArray a=new JSONArray();for(Song s:songs){JSONObject o=new JSONObject();o.put("id",s.id);o.put("name",s.name);o.put("file",s.file);o.put("origin",s.origin);o.put("timestamp",s.timestamp);o.put("exif",s.exifTimestamp);o.put("width",s.width);o.put("height",s.height);o.put("size",s.size);a.put(o);}getPreferences(MODE_PRIVATE).edit().putString("songs",a.toString()).apply();}catch(Exception ignored){}}

    public static class ZoomImageView extends ImageView {
        private final ScaleGestureDetector scale; private final GestureDetector drag; private float scaleFactor=1f,dx=0,dy=0,lastX,lastY; private boolean dragging;
        public ZoomImageView(Activity c){super(c);setScaleType(ScaleType.FIT_CENTER);setBackgroundColor(Color.WHITE);setAdjustViewBounds(true);setClickable(true);setTouchListener();
            scale=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){public boolean onScale(ScaleGestureDetector d){scaleFactor=Math.max(1f,Math.min(5f,scaleFactor*d.getScaleFactor()));apply();return true;}});
            drag=new GestureDetector(c,new GestureDetector.SimpleOnGestureListener(){public boolean onDoubleTap(MotionEvent e){scaleFactor=scaleFactor>1.05f?1f:2f;dx=dy=0;apply();return true;} public boolean onDown(MotionEvent e){return true;}});
        }
        private void setTouchListener(){setOnTouchListener((v,e)->{drag.onTouchEvent(e);scale.onTouchEvent(e);if(scale.isInProgress())return true;switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:lastX=e.getX();lastY=e.getY();dragging=true;return true;case MotionEvent.ACTION_MOVE:if(dragging&&scaleFactor>1f){dx+=e.getX()-lastX;dy+=e.getY()-lastY;apply();lastX=e.getX();lastY=e.getY();}return true;case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:dragging=false;return true;}return true;});}
        private void apply(){setScaleX(scaleFactor);setScaleY(scaleFactor);setTranslationX(dx);setTranslationY(dy);}
        public void setImageFile(File f){Bitmap b=BitmapFactory.decodeFile(f.getAbsolutePath());setImageBitmap(b);scaleFactor=1f;dx=dy=0;apply();}
    }
}
